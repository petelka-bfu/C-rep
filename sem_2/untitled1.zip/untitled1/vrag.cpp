#include "vrag.h"
#include "mainwindow.h"
#include <QDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QFrame>
#include <QPixmap>
#include <QListWidget>
#include <QMessageBox>
#include <QCoreApplication>
#include <QDir>
#include <QDebug>
#include <QRandomGenerator>

Vrag::Vrag():Creature("None",0,{0,0,0}),
    damage_(0),
    rarity_("None"){};

Vrag::Vrag(const QString& name, int hp, const defence& armor, int damage, const QString& rarity)
    : Creature(name, hp, armor),
    damage_(damage),
    rarity_(rarity) {
}
Vrag::~Vrag(){};
void Vrag::display() const {
    qDebug() << "Враг:" << name_ << "| Тип:" << rarity_
             << "| HP:" << hp_
            << "Защита:" << armor_.helmet_ << "/" << armor_.breastplate_ << "/" << armor_.boots_
             << "| Урон:" << damage_;
}
QString Vrag::getRarityColor(const QString& rarity)
{
    QString lowerRarity = rarity.toLower();

    if (lowerRarity == "обычный" || lowerRarity == "common") {
        return "green";
    }
    else if (lowerRarity == "редкий" || lowerRarity == "rare") {
        return "blue";
    }
    else if (lowerRarity == "легендарный" || lowerRarity == "legendary") {
        return "orange";
    }
    else {
        return "black";
    }
}

void Vrag::craft(QWidget* parent, int row)
{
    MainWindow* mainWindow = qobject_cast<MainWindow*>(parent);

    QDialog* dialog = new QDialog(parent);
    dialog->setWindowTitle("Информация о враге");
    dialog->setModal(false);
    dialog->setAttribute(Qt::WA_DeleteOnClose);
    dialog->setFixedSize(450, 600);

    QVBoxLayout* mainLayout = new QVBoxLayout(dialog);
    mainLayout->setAlignment(Qt::AlignTop);
    mainLayout->setSpacing(15);

    QVBoxLayout* infoLayout = new QVBoxLayout();
    infoLayout->setAlignment(Qt::AlignCenter);
    infoLayout->setSpacing(12);

    // Имя врага
    QLabel* nameLabel = new QLabel(name_);
    QString rarityColor = Vrag::getRarityColor(rarity_);
    nameLabel->setStyleSheet(QString("color: %1; font-size: %2px; font-weight: bold;").arg(rarityColor).arg(FONT_SIZE));
    nameLabel->setAlignment(Qt::AlignCenter);
    infoLayout->addWidget(nameLabel);

    // HP
    QLabel* hpLabel = new QLabel(QString("%1").arg(hp_));
    hpLabel->setStyleSheet(QString("color: red; font-size: %1px; font-weight: bold;").arg(FONT_SIZE));
    hpLabel->setAlignment(Qt::AlignCenter);
    infoLayout->addWidget(hpLabel);

    // Урон
    QLabel* damageLabel = new QLabel(QString("%1").arg(damage_));
    damageLabel->setStyleSheet(QString("color: black; font-size: %1px; font-weight: bold;").arg(FONT_SIZE));
    damageLabel->setAlignment(Qt::AlignCenter);
    infoLayout->addWidget(damageLabel);

    // Защита
    QLabel* defenceLabel = new QLabel(QString("%1/%2/%3")
                                          .arg(armor_.helmet_)
                                          .arg(armor_.breastplate_)
                                          .arg(armor_.boots_));
    defenceLabel->setStyleSheet(QString("font-size: %1px;").arg(FONT_SIZE));
    defenceLabel->setAlignment(Qt::AlignCenter);
    infoLayout->addWidget(defenceLabel);

    mainLayout->addLayout(infoLayout);

    mainLayout->addSpacing(10);

    // Фото врага
    QLabel* photoLabel = new QLabel(dialog);
    photoLabel->setAlignment(Qt::AlignCenter);
    photoLabel->setFixedSize(180, 180);
    photoLabel->setStyleSheet("border: 1px solid gray; background-color: #f0f0f0;");

    QString folderPath = QCoreApplication::applicationDirPath() + "/vrag_res";
    QDir directory(folderPath);
    QStringList filters;
    filters << "*.png" << "*.jpg" << "*.jpeg" << "*.bmp";
    QStringList imageFiles = directory.entryList(filters, QDir::Files);

    if (!imageFiles.isEmpty()) {
        int randomIndex = QRandomGenerator::global()->bounded(imageFiles.size());
        QString photoPath = folderPath + "/" + imageFiles[randomIndex];
        QPixmap pixmap(photoPath);
        if (!pixmap.isNull()) {
            photoLabel->setPixmap(pixmap.scaled(180, 180, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        } else {
            photoLabel->setText("Нет фото");
            photoLabel->setAlignment(Qt::AlignCenter);
        }
    } else {
        photoLabel->setText("Нет фото\nв папке vrag_res");
        photoLabel->setAlignment(Qt::AlignCenter);
    }
    mainLayout->addWidget(photoLabel, 0, Qt::AlignCenter);

    mainLayout->addSpacing(10);

    // Разделительная линия
    QFrame* line = new QFrame(dialog);
    line->setFrameShape(QFrame::HLine);
    line->setFrameShadow(QFrame::Sunken);
    mainLayout->addWidget(line);

    // ========== ТРИ КНОПКИ В РЯД ==========
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->setContentsMargins(20, 10, 20, 10);
    buttonLayout->setSpacing(15);

    // Кнопка "Печать" (синяя)
    QPushButton* printButton = new QPushButton("Печать", dialog);
    printButton->setFixedSize(120, 40);
    printButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #2196F3; "
        "    color: white; "
        "    font-size: 14px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #0b7dda; "
        "}"
        );

    // Кнопка "Выбрать фото" (зеленая)
    QPushButton* choosePhotoButton = new QPushButton("Выбрать фото", dialog);
    choosePhotoButton->setFixedSize(120, 40);
    choosePhotoButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #4CAF50; "
        "    color: white; "
        "    font-size: 12px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #45a049; "
        "}"
        );

    // Кнопка "Отмена" (красная)
    QPushButton* cancelButton = new QPushButton("Отмена", dialog);
    cancelButton->setFixedSize(120, 40);
    cancelButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #f44336; "
        "    color: white; "
        "    font-size: 14px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #da190b; "
        "}"
        );

    buttonLayout->addWidget(printButton);
    buttonLayout->addWidget(choosePhotoButton);
    buttonLayout->addWidget(cancelButton);

    mainLayout->addLayout(buttonLayout);
    // ===================================

    // ========== ПОДКЛЮЧЕНИЕ СИГНАЛОВ ==========

    // Отмена - закрывает диалог
    QObject::connect(cancelButton, &QPushButton::clicked, [dialog, mainWindow]() {
        if (mainWindow) {
            mainWindow->setDialogOpen(false);
        }
        dialog->close();
    });

    // Печать - удаляет объект из файла и из памяти, обновляет таблицу, закрывает диалог
    QObject::connect(printButton, &QPushButton::clicked, [this, dialog, mainWindow, row]() {
        QMessageBox::information(dialog, "Печать", QString("Печать информации о враге %1").arg(name_));

        if (mainWindow) {
            // Удаляем объект из файла
            mainWindow->deleteCreatureFromFile(row);

            // Обновляем таблицу
            mainWindow->updateTable();
        }

        // Закрываем диалог
        dialog->close();
    });

    // Выбрать фото
    QObject::connect(choosePhotoButton, &QPushButton::clicked, [this, dialog, photoLabel, mainWindow]() {
        if (!mainWindow) {
            QMessageBox::warning(dialog, "Ошибка", "Не удалось получить доступ к MainWindow");
            return;
        }

        QStringList photos = mainWindow->getPhotosFromFolder("vrag_res");

        if (photos.isEmpty()) {
            QMessageBox::warning(dialog, "Нет фото", "В папке vrag_res нет фотографий!");
            return;
        }

        QDialog* photoDialog = new QDialog(dialog);
        photoDialog->setWindowTitle("Выберите фото для врага");
        photoDialog->setModal(true);
        photoDialog->setFixedSize(400, 500);

        QVBoxLayout* layout = new QVBoxLayout(photoDialog);

        QLabel* titleLabel = new QLabel("Выберите фото:", photoDialog);
        titleLabel->setAlignment(Qt::AlignCenter);
        titleLabel->setStyleSheet("font-size: 14px; font-weight: bold; margin: 10px;");
        layout->addWidget(titleLabel);

        QListWidget* listWidget = new QListWidget(photoDialog);
        listWidget->setIconSize(QSize(60, 60));
        listWidget->setGridSize(QSize(180, 100));

        QString photoFolderPath = QCoreApplication::applicationDirPath() + "/vrag_res/";

        for (const QString& photo : photos) {
            QListWidgetItem* item = new QListWidgetItem(photo);
            QPixmap pixmap(photoFolderPath + photo);
            if (!pixmap.isNull()) {
                item->setIcon(QIcon(pixmap.scaled(60, 60, Qt::KeepAspectRatio)));
            }
            item->setSizeHint(QSize(160, 70));
            listWidget->addItem(item);
        }

        layout->addWidget(listWidget);

        QHBoxLayout* btnLayout = new QHBoxLayout();
        QPushButton* okButton = new QPushButton("Выбрать", photoDialog);
        QPushButton* cancelPhotoButton = new QPushButton("Отмена", photoDialog);

        btnLayout->addStretch();
        btnLayout->addWidget(okButton);
        btnLayout->addWidget(cancelPhotoButton);
        btnLayout->addStretch();

        layout->addLayout(btnLayout);

        QObject::connect(okButton, &QPushButton::clicked, [photoDialog, listWidget, photoLabel, photoFolderPath]() {
            QListWidgetItem* currentItem = listWidget->currentItem();
            if (currentItem) {
                QString selectedPhoto = currentItem->text();
                QPixmap pixmap(photoFolderPath + selectedPhoto);
                if (!pixmap.isNull()) {
                    photoLabel->setPixmap(pixmap.scaled(180, 180, Qt::KeepAspectRatio, Qt::SmoothTransformation));
                }
            }
            photoDialog->accept();
        });

        QObject::connect(cancelPhotoButton, &QPushButton::clicked, photoDialog, &QDialog::reject);

        photoDialog->exec();
    });

    // При закрытии диалога
    QObject::connect(dialog, &QDialog::finished, [mainWindow, dialog]() {
        if (mainWindow) {
            mainWindow->setDialogOpen(false);
        }
        dialog->deleteLater();
    });

    dialog->show();
}
