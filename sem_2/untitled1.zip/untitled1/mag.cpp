#include "mag.h"
#include "mainwindow.h"
#include <QDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QFrame>
#include <QPixmap>
#include <QMessageBox>
#include <QCoreApplication>
#include <QDir>
#include <QListWidget>
#include <QFileDialog>
#include <QRandomGenerator>

Mag::Mag():Creature("u",0,{0,0,0}),
    mana_(0),
    element_("None"){};

Mag::Mag(const QString& name, int hp, const defence& armor, int mana, const QString& element)
    : Creature(name, hp, armor),
    mana_(mana),
    element_(element) {
}
Mag::~Mag(){};
void Mag::display() const {
    qDebug() << "Маг:" << name_ << "| HP:" << hp_
             << "Защита:" << armor_.helmet_ << "/" << armor_.breastplate_ << "/" << armor_.boots_
             << "| Мана:" << mana_ << "| Стихия:" << element_;
}

QString Mag::getElementColor(const QString& element)
{
    QString lowerElement = element.toLower();

    if (lowerElement == "огонь" || lowerElement == "fire") {
        return "red";
    }
    else if (lowerElement == "вода" || lowerElement == "water") {
        return "blue";
    }
    else if (lowerElement == "земля" || lowerElement == "earth") {
        return "brown";
    }
    else {
        return "black";
    }
}
void Mag::craft(QWidget* parent, int row)
{
     MainWindow* mainWindow = qobject_cast<MainWindow*>(parent);

    QDialog* dialog = new QDialog(parent);
    dialog->setWindowTitle("Информация о маге");
    dialog->setModal(false);
    dialog->setFixedSize(450, 550);

    QVBoxLayout* mainLayout = new QVBoxLayout(dialog);
    mainLayout->setAlignment(Qt::AlignTop);
    mainLayout->setSpacing(15);

    // Имя мага
    QLabel* nameLabel = new QLabel(name_, dialog);
    nameLabel->setStyleSheet(QString("font-size: %1px; font-weight: bold; color: black;").arg(FONT_SIZE));
    nameLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(nameLabel);

    // Стихия
    QLabel* elementLabel = new QLabel(element_, dialog);
    QString elementColor = Mag::getElementColor(element_);
    elementLabel->setStyleSheet(QString("color: %1; font-size: %2px; font-weight: bold;").arg(elementColor).arg(FONT_SIZE));
    elementLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(elementLabel);

    // HP и Мана в одной строке
    QWidget* hpManaWidget = new QWidget();
    QHBoxLayout* hpManaLayout = new QHBoxLayout(hpManaWidget);
    hpManaLayout->setAlignment(Qt::AlignCenter);
    hpManaLayout->setSpacing(40);

    QLabel* hpLabel = new QLabel(QString::number(hp_));
    hpLabel->setStyleSheet(QString("color: green; font-size: %1px; font-weight: bold;").arg(FONT_SIZE));

    QLabel* manaLabel = new QLabel(QString::number(mana_));
    manaLabel->setStyleSheet(QString("color: blue; font-size: %1px; font-weight: bold;").arg(FONT_SIZE));

    hpManaLayout->addWidget(hpLabel);
    hpManaLayout->addWidget(manaLabel);
    mainLayout->addWidget(hpManaWidget);

    // Защита
    QLabel* defenceLabel = new QLabel(QString("%1/%2/%3")
                                          .arg(armor_.helmet_)
                                          .arg(armor_.breastplate_)
                                          .arg(armor_.boots_));
    defenceLabel->setStyleSheet(QString("color: black; font-size: %1px;").arg(FONT_SIZE));
    defenceLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(defenceLabel);

    mainLayout->addSpacing(20);

    // Фото мага
    QLabel* photoLabel = new QLabel(dialog);
    photoLabel->setAlignment(Qt::AlignCenter);

    // Путь к фото
    QString folderPath = QCoreApplication::applicationDirPath() + "/mag_res";
    QDir directory(folderPath);
    QStringList filters;
    filters << "*.png" << "*.jpg" << "*.jpeg" << "*.bmp";
    QStringList imageFiles = directory.entryList(filters, QDir::Files);

    if (!imageFiles.isEmpty()) {
        int randomIndex = rand() % imageFiles.size();
        QString photoPath = folderPath + "/" + imageFiles[randomIndex];
        QPixmap pixmap(photoPath);
        if (!pixmap.isNull()) {
            photoLabel->setPixmap(pixmap.scaled(180, 180, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        } else {
            photoLabel->setText("Нет фото");
            photoLabel->setFixedSize(180, 180);
            photoLabel->setStyleSheet("border: 1px solid gray; background-color: #f0f0f0;");
        }
    } else {
        photoLabel->setText("Нет фото");
        photoLabel->setFixedSize(180, 180);
        photoLabel->setStyleSheet("border: 1px solid gray; background-color: #f0f0f0;");
    }
    photoLabel->setFixedSize(180, 180);
    mainLayout->addWidget(photoLabel, 0, Qt::AlignCenter);



    // Разделительная линия
    QFrame* line = new QFrame(dialog);
    line->setFrameShape(QFrame::HLine);
    line->setFrameShadow(QFrame::Sunken);
    mainLayout->addWidget(line);

    // Кнопки - три кнопки в ряд
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->setContentsMargins(20, 10, 20, 10);
    buttonLayout->setSpacing(15);  // Расстояние между кнопками

    // Кнопка "Печать" (синяя) - слева
    QPushButton* printButton = new QPushButton("Печать", dialog);
    printButton->setFixedSize(120, 40);
    printButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #2196F3; "
        "    color: white; "
        "    font-size: 14px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #0b7dda; "
        "}"
        );

    // Кнопка "Выбрать фото" (зеленая) - по центру
    QPushButton* choosePhotoButton = new QPushButton("Выбрать фото", dialog);
    choosePhotoButton->setFixedSize(120, 40);
    choosePhotoButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #4CAF50; "
        "    color: white; "
        "    font-size: 12px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #45a049; "
        "}"
        );
    QObject::connect(choosePhotoButton, &QPushButton::clicked, [this, dialog, photoLabel, mainWindow]() {
        // Получаем список фото из папки mag_res
        QStringList photos = mainWindow->getPhotosFromFolder("mag_res");

        if (photos.isEmpty()) {
            QMessageBox::warning(dialog, "Нет фото", "В папке mag_res нет фотографий!");
            return;
        }

        // Создаем диалог выбора фото
        QDialog* photoDialog = new QDialog(dialog);
        photoDialog->setWindowTitle("Выберите фото для мага");
        photoDialog->setModal(true);
        photoDialog->setFixedSize(400, 500);

        QVBoxLayout* layout = new QVBoxLayout(photoDialog);

        QLabel* titleLabel = new QLabel("Выберите фото:", photoDialog);
        titleLabel->setAlignment(Qt::AlignCenter);
        titleLabel->setStyleSheet("font-size: 14px; font-weight: bold; margin: 10px;");
        layout->addWidget(titleLabel);

        // Список фото
        QListWidget* listWidget = new QListWidget(photoDialog);
        listWidget->setIconSize(QSize(60, 60));
        listWidget->setGridSize(QSize(180, 100));

        QString folderPath = QCoreApplication::applicationDirPath() + "/mag_res/";

        for (const QString& photo : photos) {
            QListWidgetItem* item = new QListWidgetItem(photo);

            QPixmap pixmap(folderPath + photo);
            if (!pixmap.isNull()) {
                item->setIcon(QIcon(pixmap.scaled(60, 60, Qt::KeepAspectRatio)));
            }

            item->setSizeHint(QSize(160, 70));
            listWidget->addItem(item);
        }

        layout->addWidget(listWidget);

        // Кнопки
        QHBoxLayout* buttonLayout = new QHBoxLayout();
        QPushButton* okButton = new QPushButton("Выбрать", photoDialog);
        QPushButton* cancelButton = new QPushButton("Отмена", photoDialog);

        buttonLayout->addStretch();
        buttonLayout->addWidget(okButton);
        buttonLayout->addWidget(cancelButton);
        buttonLayout->addStretch();

        layout->addLayout(buttonLayout);

        QObject::connect(okButton, &QPushButton::clicked, [photoDialog, listWidget, photoLabel, folderPath]() {
            QListWidgetItem* currentItem = listWidget->currentItem();
            if (currentItem) {
                QString selectedPhoto = currentItem->text();
                QPixmap pixmap(folderPath + selectedPhoto);
                if (!pixmap.isNull()) {
                    photoLabel->setPixmap(pixmap.scaled(180, 180, Qt::KeepAspectRatio, Qt::SmoothTransformation));
                }
            }
            photoDialog->accept();
        });

        QObject::connect(cancelButton, &QPushButton::clicked, photoDialog, &QDialog::reject);

        photoDialog->exec();
    });

    mainLayout->addWidget(choosePhotoButton, 0, Qt::AlignCenter);

    mainLayout->addSpacing(10);

    // Кнопка "Отмена" (красная) - справа
    QPushButton* cancelButton = new QPushButton("Отмена", dialog);
    cancelButton->setFixedSize(120, 40);
    cancelButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #f44336; "
        "    color: white; "
        "    font-size: 14px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #da190b; "
        "}"
        );

    // Добавляем все три кнопки в layout
    buttonLayout->addWidget(printButton);
    buttonLayout->addWidget(choosePhotoButton);
    buttonLayout->addWidget(cancelButton);

    mainLayout->addLayout(buttonLayout);

    // Подключаем кнопки
    QObject::connect(cancelButton, &QPushButton::clicked, dialog, &QDialog::close);
    QObject::connect(printButton, &QPushButton::clicked, [this, dialog, mainWindow, row]() {
        QMessageBox::information(dialog, "Печать", QString("Печать информации о маге %1").arg(name_));

        if (mainWindow) {
            // Удаляем объект из файла
            mainWindow->deleteCreatureFromFile(row);

            // Удаляем объект из памяти
            delete mainWindow->getCreatureAt(row);

            // Удаляем указатель из вектора
            mainWindow->removeCreatureAt(row);

            // Обновляем таблицу
            mainWindow->updateTable();
        }

        dialog->close();
    });
    QObject::connect(dialog, &QDialog::finished, [mainWindow, dialog]() {
        if (mainWindow) {
            mainWindow->setDialogOpen(false);
        }
        dialog->deleteLater();
    });

    dialog->show();
}
