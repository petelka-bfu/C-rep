#ifndef MAG_H
#define MAG_H
#include "creature.h"

class Mag : public Creature{
public:
     void craft(QWidget* parent, int row) override;
    int getMana() const { return mana_; }
    QString getElement() const { return element_; }
    void display() const override;
    Mag();
    Mag(const QString& name, int hp, const defence& armor, int mana, const QString& element);
    ~Mag();
    static QString getElementColor(const QString& element);
private:
    int mana_;
    QString element_;
};
#endif // MAG_H
