#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include "creature.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QString getElementColor(const QString& element);
    QString getRarity(const QString& rarity);
    QString getRandomPhotoFromFolder(const QString& folderName);
    void extracted(QStringList &lines, QTextStream &out);
    void deleteCreatureFromFile(int index);
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Creature* getCreatureAt(int index);
    void removeCreatureAt(int index);
    QStringList getPhotosFromFolder(const QString& folderName);
    void setDialogOpen(bool open) { m_dialogOpen = open; }
    void centerTableWidget();
    void on_tableWidget_cellDoubleClicked(int row, int column);
    void loadFile(const QString& filePath);
    void updateTable();
    void clearCreatures();
    void extracted();
private slots:
    void on_loadButton_clicked();

private:

    static const short FONT_SIZE = 30;
    bool m_dialogOpen = false;
    Ui::MainWindow *ui;
    QVector<Creature*> creatures;


};

#endif // MAINWINDOW_H
