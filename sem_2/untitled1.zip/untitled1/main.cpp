#include "mainwindow.h"

#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QVector>
#include <qapplication.h>
#include "creature.h"
#include "mag.h"
#include "vrag.h"

int main(int argc, char *argv[]) {

    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();

    // Вектор обычных указателей
    QVector<Creature*> creatures;

    QFile file("C:/Users/admin/Documents/untitled1/creatures.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Ошибка: не удалось открыть файл!";
        return 1;
    }

    QTextStream in(&file);

    int lineNumber = 0;
    int successCount = 0;
    int errorCount = 0;

    qDebug() << "=== Чтение файла ===\n";

    while (!in.atEnd()) {
        lineNumber++;
        QString line = in.readLine();

        if (line.trimmed().isEmpty()) {
            continue;
        }

        qDebug() << "Строка" << lineNumber << ":" << line;

        QStringList parts = line.split(' ', Qt::SkipEmptyParts);

        if (parts.size() < 7) {
            qDebug() << "  Недостаточно данных";
            errorCount++;
            continue;
        }

        bool ok;
        int typeCode = parts[0].toInt(&ok);

        if (!ok) {
            qDebug() << "  Первый токен не число:" << parts[0];
            errorCount++;
            continue;
        }

        QString name = parts[1];
        int hp = parts[4].toInt();

        defence defence;
        defence.helmet_ = parts[5].toInt();
        defence.breastplate_= parts[6].toInt();
        defence.boots_ = parts[7].toInt();

        qDebug() << "  Тип:" << typeCode << "Имя:" << name << "HP:" << hp
                 << "Защита:" << defence.helmet_ << "/" << defence.breastplate_ << "/" << defence.boots_;

        // СОЗДАЕМ ОБЪЕКТ ЧЕРЕЗ new И ДОБАВЛЯЕМ В ВЕКТОР
        switch (typeCode) {
        case 1: {  // Маг
            if (parts.size() < 8) {
                qDebug() << "  Для мага нужно 8 полей";
                errorCount++;
                continue;
            }
            int mana = parts[3].toInt();
            QString element = parts[2];

            // ✅ Создаем объект через new
            Mag* mag = new Mag(name, hp, defence, mana, element);
            creatures.push_back(mag);

            successCount++;
            qDebug() << "  ✅ Создан маг";
            break;
        }

        case 2: {  // Враг
            if (parts.size() < 8) {
                qDebug() << "  Для врага нужно 8 полей";
                errorCount++;
                continue;
            }
            int damage = parts[3].toInt();
            QString type = parts[2];

            // ✅ Создаем объект через new
            Vrag* enemy = new Vrag(name, hp, defence, damage, type);
            creatures.push_back(enemy);

            successCount++;
            qDebug() << "  ✅ Создан враг";
            break;
        }

        default:
            qDebug() << "  ❌ Неизвестный тип:" << typeCode;
            errorCount++;
            break;
        }
    }

    file.close();

    qDebug() << "\n========================================";
    qDebug() << "Результат:";
    qDebug() << "✅ Успешно:" << successCount;
    qDebug() << "❌ Ошибок:" << errorCount;
    qDebug() << "========================================\n";

    qDebug() << "=== Список существ ===";
    for (const auto& creature : creatures) {
        creature->display();
    }

    qDebug() << "\nВсего создано объектов:" << creatures.size();

    //ОСВОБОЖДАЕМ ПАМЯТЬ
    qDebug() << "\n=== Освобождение памяти ===";
    for (Creature* creature : creatures) {
        delete creature;
    }
    creatures.clear();

    qDebug() << "Память освобождена";

    return 0;
}
