#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "creature.h"
#include "mag.h"
#include "vrag.h"
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QCoreApplication>
#include <QTableWidget>        // для работы с таблицей
#include <QHeaderView>         // для заголовков таблицы
#include <QVBoxLayout>         // для вертикальной компоновки
#include <QLabel>              // для текстовых меток
#include <QPushButton>         // для кнопок
#include <QDialog>
#include <QDir>
#include <QRandomGenerator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    centerTableWidget();
    connect(ui->tableWidget, &QTableWidget::cellDoubleClicked,
            this, &MainWindow::on_tableWidget_cellDoubleClicked); // событие двойного нажатия
}

MainWindow::~MainWindow()
{
    clearCreatures();
    delete ui;
}
Creature* MainWindow::getCreatureAt(int index)
{
    if (index >= 0 && index < creatures.size()) {
        return creatures[index];
    }
    return nullptr;
}

void MainWindow::removeCreatureAt(int index)
{
    if (index >= 0 && index < creatures.size()) {
        creatures.removeAt(index);
    }
}
QStringList MainWindow::getPhotosFromFolder(const QString& folderName)
{
    QString folderPath = QCoreApplication::applicationDirPath() + "/" + folderName;
    QDir directory(folderPath);

    QStringList filters;
    filters << "*.png" << "*.jpg" << "*.jpeg" << "*.bmp" << "*.gif";

    return directory.entryList(filters, QDir::Files);
}
QString MainWindow::getElementColor(const QString& element)
{
    QString lowerElement = element.toLower();

    if (lowerElement == "огонь" || lowerElement == "fire") {
        return "red";
    }
    else if (lowerElement == "вода" || lowerElement == "water") {
        return "blue";
    }

    else if (lowerElement == "земля" || lowerElement == "earth") {
        return "brown";
    }
    else {
        return "black"; // цвет по умолчанию
    }
}
//функция для определения цвета текста в зависимости от редкости
QString getRarityColor(const QString& rarity){
    QString lowerRarity = rarity.toLower();
    if (lowerRarity == "обычный" || lowerRarity == "common") {
        return "green";
    }
    else if (lowerRarity == "редкий" || lowerRarity == "rare") {
        return "blue";
    }
    else if (lowerRarity == "легендарный" || lowerRarity == "legendary") {
        return "yellow";
    }

    else {
        return "black"; // цвет по умолчанию
    }
}

QString MainWindow::getRandomPhotoFromFolder(const QString& folderName)
{
    // Путь к папке с фото
    QString folderPath = QCoreApplication::applicationDirPath() + "/" + folderName;

    QDir directory(folderPath);

    // Проверяем, существует ли папка
    if (!directory.exists()) {
        qDebug() << "Папка не существует:" << folderPath;
        return QString();
    }

    // Фильтруем только файлы изображений
    QStringList filters;
    filters << "*.png" << "*.jpg" << "*.jpeg" << "*.bmp" << "*.gif";

    // Получаем список всех файлов изображений в папке
    QStringList imageFiles = directory.entryList(filters, QDir::Files);

    if (imageFiles.isEmpty()) {
        qDebug() << "В папке нет изображений:" << folderPath;
        return QString();
    }

    // Выбираем случайный файл
    int randomIndex = QRandomGenerator::global()->bounded(imageFiles.size());
    QString randomFileName = imageFiles[randomIndex];

    qDebug() << "Выбрано случайное фото:" << randomFileName;

    // Возвращаем полный путь к случайному файлу
    return folderPath + "/" + randomFileName;
}
void MainWindow::deleteCreatureFromFile(int index)
{
    if (index < 0 || index >= creatures.size()) {
        return;
    }

    // Получаем путь к файлу
    QString filePath = QCoreApplication::applicationDirPath() + "/creatures.txt";
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для чтения");
        return;
    }

    // Читаем все строки
    QTextStream in(&file);
    QStringList lines;
    while (!in.atEnd()) {
        lines << in.readLine();
    }
    file.close();

    // Проверяем, что индекс существует
    if (index >= lines.size()) {
        return;
    }

    // Удаляем нужную строку
    lines.removeAt(index);

    // Записываем обратно
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи");
        return;
    }

    QTextStream out(&file);
    for (const QString& line : lines) {
        if (!line.trimmed().isEmpty()) {
            out << line << "\n";
        }
    }
    file.close();
}
void MainWindow::on_tableWidget_cellDoubleClicked(int row, int column)
{
    if (row < 0 || row >= creatures.size()) {
        return;
    }

    Creature* creature = creatures[row];

    creature->craft(this, row);


}
void MainWindow::on_loadButton_clicked()
{
    static bool isProcessing = false;
    if (isProcessing) {
        return;
    }
    isProcessing = true;
    QMessageBox msgBox;
    msgBox.setWindowTitle("Выбор файла");
    msgBox.setText("Как загрузить данные?");

    QPushButton *defaultBtn = msgBox.addButton("Дефолтный файл", QMessageBox::ActionRole);
    QPushButton *chooseBtn = msgBox.addButton("Выбрать файл", QMessageBox::ActionRole);
    QPushButton *cancelBtn = msgBox.addButton("Отмена", QMessageBox::RejectRole);

    msgBox.exec();

    if (msgBox.clickedButton() == defaultBtn) {
        QString path = QCoreApplication::applicationDirPath() + "/creatures.txt";
        loadFile(path);
    }
    else if (msgBox.clickedButton() == chooseBtn) {
        QString path = QFileDialog::getOpenFileName(this, "Выберите файл", QDir::homePath(), "*.txt");
        if (!path.isEmpty()) {
            loadFile(path);
        }
    }
    isProcessing = false;
}

void MainWindow::loadFile(const QString& filePath)
{
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл");
        return;
    }

    clearCreatures();

    QTextStream in(&file);

    int count = 0;

    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) continue;

        QStringList parts = line.split(' ', Qt::SkipEmptyParts);
        if (parts.size() < 8) continue;

        int typeCode = parts[0].toInt();
        QString name = parts[1];
        int hp = parts[4].toInt();

        defence defence;
        defence.helmet_= parts[5].toInt();
        defence.breastplate_ = parts[6].toInt();
        defence.boots_ = parts[7].toInt();

        if (typeCode == 1) {
            int mana = parts[3].toInt();
            QString element = parts[2];
            creatures.push_back(new Mag(name, hp, defence, mana, element));
            count++;
        }
        else if (typeCode == 2) {
            int damage = parts[3].toInt();
            QString type = parts[2];
            creatures.push_back(new Vrag(name, hp, defence, damage, type));
            count++;
        }
    }

    file.close();

    updateTable();
    QMessageBox::information(this, "Готово", QString("Загружено существ: %1").arg(count));
}


void MainWindow::updateTable()
{
    ui->tableWidget->setRowCount(creatures.size());
    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->setHorizontalHeaderLabels({"Тип", "Имя", "Защита", "Спец2"});
    ui->tableWidget->setFixedWidth(272); //ширина таблицы сделана так чтобы столбцы ровно умещались
    for (int i = 0; i < creatures.size(); ++i) {
        Creature* c = creatures[i];

        if (dynamic_cast<Mag*>(c)) {
            ui->tableWidget->setItem(i, 0, new QTableWidgetItem("Маг"));
        } else {
            ui->tableWidget->setItem(i, 0, new QTableWidgetItem("Враг"));
        }

        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(c->getName()));

        defence d = c->getDefence();
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(
                                           QString::number(d.helmet_) + "/" + QString::number(d.breastplate_) + "/" + QString::number(d.boots_)));

        if (auto* mag = dynamic_cast<Mag*>(c)) {

            ui->tableWidget->setItem(i, 3, new QTableWidgetItem(mag->getElement()));
        }
        else if (auto* enemy = dynamic_cast<Vrag*>(c)) {
            ui->tableWidget->setItem(i, 3, new QTableWidgetItem(enemy->getType()));
        }
    }

    ui->tableWidget->resizeColumnsToContents();
    statusBar()->showMessage(QString("Всего: %1").arg(creatures.size()));
}

void MainWindow::extracted() {
    for (Creature *c : creatures) {
        delete c;
    }
}
void MainWindow::clearCreatures() {
    extracted();
    creatures.clear();
}
void MainWindow::centerTableWidget()
{
    QWidget* parent = ui->tableWidget->parentWidget();

    if (!parent) return;

    // Удаляем старый layout если есть
    QLayout* oldLayout = parent->layout();
    if (oldLayout) {
        delete oldLayout;
    }

    // Создаем вертикальный layout
    QVBoxLayout* mainLayout = new QVBoxLayout(parent);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(20);

    // Добавляем растяжку сверху
    mainLayout->addStretch();

    // Создаем контейнер для таблицы и кнопки
    QWidget* container = new QWidget();
    QVBoxLayout* containerLayout = new QVBoxLayout(container);
    containerLayout->setAlignment(Qt::AlignCenter);
    containerLayout->setSpacing(15);

    // Горизонтальный layout для таблицы (центрирование)
    QHBoxLayout* tableLayout = new QHBoxLayout();
    tableLayout->addStretch();
    tableLayout->addWidget(ui->tableWidget);
    tableLayout->addStretch();

    // НАСТРОЙКА ТАБЛИЦЫ: ПОЛНЫЙ ЗАПРЕТ РАСТЯГИВАНИЯ
    // Устанавливаем точный фиксированный размер
    ui->tableWidget->setFixedSize(500, 300);

    // Запрещаем любые изменения размера через политику
    ui->tableWidget->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

    // Запрещаем изменение размеров столбцов и строк
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);

    // Дополнительно отключаем возможность изменения размера через стили
    ui->tableWidget->setStyleSheet(
        "QTableWidget {"
        "    border: 1px solid #ddd;"
        "    gridline-color: #ccc;"
        "}"
        "QTableWidget::item {"
        "    padding: 5px;"
        "}"
        );

    // Отключаем автоматическое изменение размера
    ui->tableWidget->setAutoScroll(false);

    // Настройка кнопки
    ui->loadButton->setFixedWidth(150);
    ui->loadButton->setFixedHeight(35);
    ui->loadButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #2196F3; "
        "    color: white; "
        "    font-size: 14px; "
        "    font-weight: bold; "
        "    border-radius: 5px; "
        "    border: none;"
        "}"
        "QPushButton:hover {"
        "    background-color: #0b7dda; "
        "}"
        );

    // Горизонтальный layout для кнопки (центрирование)
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    buttonLayout->addWidget(ui->loadButton);
    buttonLayout->addStretch();

    // Добавляем в контейнер
    containerLayout->addLayout(tableLayout);
    containerLayout->addLayout(buttonLayout);

    // Добавляем контейнер в главный layout
    mainLayout->addWidget(container);

    // Добавляем растяжку снизу
    mainLayout->addStretch();
}
