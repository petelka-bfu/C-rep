#include "creature.h"


Creature::Creature() : name_("None"), hp_(0),armor_{0,0,0}{
}
Creature::Creature(const QString& name, int hp, const defence& armor){
    name_ = name;
    hp_ = hp;
    armor_ = armor;
}
Creature::~Creature(){};
void Creature::display() const {
    qDebug() << "Существо:" << name_ << "HP:" << hp_
             << "Защита:" << armor_.helmet_ << "/" << armor_.breastplate_ << "/" << armor_.boots_;
}
