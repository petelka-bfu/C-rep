#ifndef VRAG_H
#define VRAG_H
#include "creature.h"
class Vrag : public Creature {
private:
    int damage_;
    QString rarity_;

public:
    Vrag();
    static QString getRarityColor(const QString& rarity);
    Vrag(const QString& name, int hp, const defence& defence, int damage, const QString& type);
    ~Vrag();
    void craft(QWidget* parent, int row) override;

    // Геттеры
    int getDamage() const { return damage_; }
    QString getType() const { return rarity_; }

    void display() const override;
};
#endif // VRAG_H
