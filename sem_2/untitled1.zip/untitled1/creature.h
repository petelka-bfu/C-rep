#ifndef CREATURE_H
#define CREATURE_H
#include <QtDebug>
#include <QVector>
#include <QString>
#include <QTextStream>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QCoreApplication>
#include <QTableWidget>        // для работы с таблицей
#include <QHeaderView>         // для заголовков таблицы
#include <QVBoxLayout>         // для вертикальной компоновки
#include <QLabel>              // для текстовых меток
#include <QPushButton>         // для кнопок
#include <QDialog>
#include <QDir>
#include <QRandomGenerator>
struct defence {
    int helmet_;
    int breastplate_;
    int boots_;
    defence(int h = 0, int b = 0, int l = 0) : helmet_(h), breastplate_(b), boots_(l) {}
};
class Creature
{
protected:
    QString name_;
    int hp_;
    defence armor_;
    static const short FONT_SIZE = 30;


public:
    virtual void craft(QWidget* parent, int row) = 0;
    virtual void display() const;
    //геттеры
    QString getName() const { return name_; }
    int getHp() const { return hp_; }
    defence getDefence() const { return armor_; }

    //сеттеры
    void setName(const QString& n) { name_ = n; }
    void setHp(int h) { hp_ = h; }
    void setDefence(const defence& d) { armor_ = d; }

    //конструкторы деструкторы и крафт
    //virtual void Craft();
    Creature();
    Creature(const QString& name, int hp, const defence& armor);
    virtual ~Creature();

};
#endif // CREATURE_H
